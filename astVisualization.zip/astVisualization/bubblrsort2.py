import instaviz1
def bubblesort(a,num):
	for i in range(number -1):
		for j in range(number - i - 1):
			if(a[j] > a[j + 1]):
				temp=a[j]
				a[j]=a[j+1]
				a[j+1]=temp
instaviz1.show(bubblesort)
	
