import instaviz1


def foo():
    a = 1
    b = a + 1
    return b

instaviz1.show(foo)
